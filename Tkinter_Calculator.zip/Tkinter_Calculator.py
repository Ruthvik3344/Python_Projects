from tkinter import*
root = Tk()
root.geometry("420x420")
root.title("Calculator")
menu=Menu(root)
Exit=Menu(menu,tearoff=False)
Exit.add_command(label="Exit",command=root.destroy)
menu.add_cascade(label="Exit",menu=Exit)
root.config(bg="cyan",menu=menu)
calc=Label(root,bg="silver",text="Basic Calculator",font=("algerian",12,"bold"))
calc.pack(fill=X)
e=Entry(root,width=56,borderwidth=7)
e.place(x=35,y=50)

def click(num):
    result=e.get()
    e.delete(0,END)
    e.insert(0,str(result)+str(num))
b=Button(root,text="1",width=12,command=lambda:click(1),bg="lightgreen")
b.place(x=60,y=110)
b=Button(root,text="2",width=12,command=lambda:click(2),bg="lightgreen")
b.place(x=155,y=110)
b=Button(root,text="3",width=12,command=lambda:click(3),bg="lightgreen")
b.place(x=250,y=110)
b=Button(root,text="4",width=12,command=lambda:click(4),bg="lightgreen")
b.place(x=60,y=140)
b=Button(root,text="5",width=12,command=lambda:click(5),bg="lightgreen")
b.place(x=155,y=140)
b=Button(root,text="6",width=12,command=lambda:click(6),bg="lightgreen")
b.place(x=250,y=140)
b=Button(root,text="7",width=12,command=lambda:click(7),bg="lightgreen")
b.place(x=60,y=170)
b=Button(root,text="8",width=12,command=lambda:click(8),bg="lightgreen")
b.place(x=155,y=170)
b=Button(root,text="9",width=12,command=lambda:click(9),bg="lightgreen")
b.place(x=250,y=170)
b=Button(root,text="0",width=12,command=lambda:click(0),bg="lightgreen")
b.place(x=155,y=200)

def add():
    n1=e.get()
    global math
    math="addition"
    global i
    i=int(n1)
    e.delete(0,END)
b=Button(root,text="+",width=12,command=add,bg="lightblue",activebackground="lightblue")
b.place(x=60,y=200)
def sub():
    n1=e.get()
    global math
    math="subtraction"
    global i
    i=int(n1)
    e.delete(0,END)
b=Button(root,text="-",width=12,command=sub,bg="lightblue",activebackground="lightblue")
b.place(x=250,y=200)
def mul():
    n1=e.get()
    global math
    math="multiplication"
    global i
    i=int(n1)
    e.delete(0,END)
b=Button(root,text="*",width=12,command=mul,bg="lightblue",activebackground="lightblue")
b.place(x=60,y=230)
def div():
    n1=e.get()
    global math
    math="division"
    global i
    i=int(n1)
    e.delete(0,END)
b=Button(root,text="/",width=12,command=div,bg="lightblue",activebackground="lightblue")
b.place(x=155,y=230)

def eql():
    n2=e.get()
    e.delete(0,END)
    if math=="addition":
        e.insert(0,i+int(n2))
    elif math=="subtraction":
        e.insert(0,i-int(n2))
    elif math=="multiplication":
        e.insert(0,i*int(n2))
    elif math=="division":
        e.insert(0,i/int(n2))
b=Button(root,text="=",width=12,command=eql,bg="lightgrey",activebackground="lightgrey",fg="brown")
b.place(x=250,y=230)

def clr():
    e.delete(0,END)
b=Button(root,text="Clear",width=39,command=clr, borderwidth=2,bg="grey",activebackground="lightBlue",font=("stencil",8))
b.place(x=60,y=290)
root.mainloop()

